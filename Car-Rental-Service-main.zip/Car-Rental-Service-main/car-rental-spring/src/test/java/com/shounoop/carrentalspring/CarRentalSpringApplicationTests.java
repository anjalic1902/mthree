package com.shounoop.carrentalspring;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSpringApplicationTests {


}
